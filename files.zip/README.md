# Employee Progress Dashboard (with CRUD)

A Streamlit dashboard backed by SQLite. Read-only analytics + full Create/Read/Update/Delete for employees, tasks, and interactions.

## Quick start

```bash
pip install -r requirements.txt
streamlit run app.py
```

On first launch, the app creates `employees.db` and seeds it with 25 sample employees, ~600 tasks, and ~700 interactions across the last 90 days. Delete `employees.db` to reset.

## File layout

| File | Purpose |
|---|---|
| `app.py` | Streamlit UI — 4 tabs, all forms, all buttons |
| `db.py` | SQLite layer — schema, CRUD functions, aggregations |
| `employees.db` | SQLite file (created at runtime, gitignore this) |
| `requirements.txt` | Dependencies |

## The four tabs

### 📊 Dashboard
Read-only analytics. KPI cards, top-10 bar chart, rating distribution, department comparison, interactions-vs-rating scatter (with diagnostic regression line), daily activity heatmap, sortable leaderboard with CSV export. Date range filter at the top — everything reflows live from the DB.

### 👥 Employees
- **Add** — name, department, email, hire date
- **Edit** — change any field, toggle active/inactive
- **Deactivate** (💤) — soft delete, preserves all task history
- **Reactivate** (♻️) — bring an inactive employee back
- **Hard delete** (🗑️) — cascade-deletes all their tasks and interactions, with a confirmation step

Toggle "Show inactive employees" to see soft-deleted records.

### ✅ Tasks
- **Add** — assignee, title, status, priority, due date, hours, optional peer rating + description
- **Edit** — every field. Moving status to `done` auto-stamps `completed_at`; moving it back clears the stamp.
- **Delete** — hard delete with confirmation
- **Filter** — by employee, status, or last-30-days

### 💬 Interactions
Lightweight log of meetings, code reviews, 1:1s, calls, mentoring. Drives the 20% engagement portion of the star rating.

## Star rating formula

Composite 1-5 score derived from real activity in the selected date window:

```
35% tasks completed (output)
30% avg peer rating (quality)
20% interactions    (engagement)
15% hours logged    (effort)
```

Edit `compute_star_rating()` in `db.py` to re-tune. The weights are deliberately not 100% interactions — that would reward Slack noise over actual work.

## Design choices worth knowing

**Soft delete for employees, hard delete for tasks.** Deleting an employee outright destroys their historical task data and breaks past dashboard views retroactively. Soft delete preserves the analytics; hard delete is available behind a confirmation if you really mean it.

**Auto-stamping completion.** When a task moves to `done`, `completed_at` gets the current timestamp. Moving back to any other status clears it. This is why the daily activity heatmap works.

**No caching on mutations.** Streamlit's `@st.cache_data` was deliberately not used on the DB reads — caching across writes causes stale data after edits. The DB queries are fast enough on SQLite that it doesn't matter at this scale.

**Foreign keys are enforced.** `PRAGMA foreign_keys = ON` is set on every connection, so cascade deletes actually fire.

## What's missing (deliberately)

These are real production concerns I didn't build. If this is for a real team, you'll need them:

1. **Authentication.** Anyone running the app can delete anything. Add login (Streamlit Auth, OAuth) before deploying.
2. **Audit log.** No record of who changed what when. Add an `audit_log` table that records every INSERT/UPDATE/DELETE if you need accountability.
3. **Concurrent writes.** SQLite handles light loads fine, but if multiple managers edit simultaneously, last write wins silently. For real concurrency, switch `db.py` to Postgres via SQLAlchemy.
4. **Cloud persistence.** On Streamlit Cloud / containers, `employees.db` lives in ephemeral storage and vanishes on restart. Mount persistent storage or use a managed Postgres.
5. **Bulk import.** No CSV upload yet. If you have existing data, add a one-time loader to `db.py` rather than typing it through the UI.

## Resetting the data

```bash
rm employees.db
streamlit run app.py  # re-seeds automatically
```
