"""
Employee Progress Dashboard — with CRUD.

Run with:
    streamlit run app.py

Four tabs:
    📊 Dashboard      — KPIs, charts, leaderboard (read-only)
    👥 Employees      — add / edit / deactivate / reactivate / hard-delete
    ✅ Tasks          — add / edit / delete
    💬 Interactions   — add / edit / delete
"""
from __future__ import annotations

from datetime import date, datetime, timedelta

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
import streamlit as st

import db


# ---------------------------------------------------------------
# Setup
# ---------------------------------------------------------------
st.set_page_config(
    page_title="Employee Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

sns.set_theme(style="whitegrid", palette="viridis")
plt.rcParams["axes.spines.top"] = False
plt.rcParams["axes.spines.right"] = False

st.markdown(
    """
    <style>
    .main { padding-top: 1rem; }
    div[data-testid="stMetricValue"] { font-size: 26px; font-weight: 700; }
    .block-container { padding-top: 2rem; padding-bottom: 2rem; }
    .stTabs [data-baseweb="tab-list"] { gap: 8px; }
    .stTabs [data-baseweb="tab"] {
        padding: 10px 20px; background-color: #f3f4f6;
        border-radius: 6px 6px 0 0;
    }
    .stTabs [aria-selected="true"] { background-color: #5b21b6; color: white; }
    </style>
    """,
    unsafe_allow_html=True,
)

# Initialise DB and seed if empty (runs once)
db.init_db()


def render_stars(rating: float) -> str:
    if rating is None or pd.isna(rating):
        return "—"
    full = int(rating)
    half = 1 if rating - full >= 0.5 else 0
    empty = 5 - full - half
    return "★" * full + "½" * half + "☆" * empty


# Session state for edit modes
for key, default in {
    "edit_employee_id": None,
    "edit_task_id": None,
    "edit_interaction_id": None,
    "delete_confirm_employee": None,
    "delete_confirm_task": None,
    "delete_confirm_interaction": None,
}.items():
    if key not in st.session_state:
        st.session_state[key] = default


# ---------------------------------------------------------------
# Tabs
# ---------------------------------------------------------------
tab_dash, tab_emp, tab_task, tab_inter = st.tabs([
    "📊 Dashboard",
    "👥 Employees",
    "✅ Tasks",
    "💬 Interactions",
])

# ===============================================================
# TAB 1 — DASHBOARD (read-only analytics)
# ===============================================================
with tab_dash:
    st.title("📊 Employee Progress Dashboard")

    # Date range filter
    col_a, col_b, col_c = st.columns([1, 1, 2])
    today = date.today()
    default_start = today - timedelta(days=90)

    with col_a:
        d_from = st.date_input("From", value=default_start, key="dash_from")
    with col_b:
        d_to = st.date_input("To", value=today, key="dash_to")
    with col_c:
        st.write("")
        st.caption(
            "Star rating = 35% tasks · 30% peer feedback · 20% interactions · 15% hours · "
            "Edit weights in `db.compute_star_rating()`."
        )

    metrics = db.employee_metrics(date_from=d_from, date_to=d_to)

    if metrics.empty:
        st.warning(
            "No employees in the database. Add some in the **Employees** tab to get started."
        )
        st.stop()

    # KPI cards
    st.markdown("---")
    k1, k2, k3, k4, k5 = st.columns(5)
    k1.metric("👥 Active Employees", f"{len(metrics)}")
    k2.metric("⭐ Avg Star Rating", f"{metrics['star_rating'].mean():.2f} / 5")
    k3.metric("✅ Tasks Completed", f"{int(metrics['tasks_completed'].sum()):,}")
    k4.metric("💬 Total Interactions", f"{int(metrics['interactions'].sum()):,}")
    k5.metric("⏱️ Hours Logged", f"{int(metrics['hours_logged'].sum()):,}")

    st.markdown("---")

    # Top 10 + Distribution
    left, right = st.columns([1.2, 1])
    with left:
        st.subheader("🏆 Top Performers")
        top10 = metrics.sort_values("star_rating", ascending=False).head(10)
        fig, ax = plt.subplots(figsize=(8, 5))
        sns.barplot(
            data=top10, x="star_rating", y="employee",
            hue="department", dodge=False, ax=ax, palette="viridis",
        )
        ax.set_xlim(0, 5)
        ax.set_xlabel("Avg Star Rating (1-5)")
        ax.set_ylabel("")
        ax.legend(title="Department", bbox_to_anchor=(1.02, 1), loc="upper left")
        for i, v in enumerate(top10["star_rating"]):
            ax.text(v + 0.05, i, f"{v:.2f} ★", va="center", fontsize=9)
        plt.tight_layout()
        st.pyplot(fig)
        plt.close(fig)

    with right:
        st.subheader("📈 Rating Distribution")
        fig, ax = plt.subplots(figsize=(6, 5))
        sns.histplot(data=metrics, x="star_rating", bins=12, kde=True,
                     color="#5b21b6", ax=ax)
        ax.axvline(metrics["star_rating"].mean(), color="#dc2626",
                   linestyle="--", linewidth=2,
                   label=f"Mean: {metrics['star_rating'].mean():.2f}")
        ax.set_xlabel("Star Rating")
        ax.set_ylabel("Employees")
        ax.legend()
        plt.tight_layout()
        st.pyplot(fig)
        plt.close(fig)

    # Department comparison + Interactions vs Rating
    left, right = st.columns(2)
    with left:
        st.subheader("🏢 Department Performance")
        dept_agg = (
            metrics.groupby("department")
            .agg(avg_rating=("star_rating", "mean"))
            .reset_index().sort_values("avg_rating")
        )
        fig, ax = plt.subplots(figsize=(8, 5))
        sns.barplot(data=dept_agg, x="avg_rating", y="department",
                    ax=ax, palette="viridis")
        ax.set_xlim(0, 5)
        ax.set_xlabel("Avg Star Rating")
        ax.set_ylabel("")
        for i, v in enumerate(dept_agg["avg_rating"]):
            ax.text(v + 0.05, i, f"{v:.2f}", va="center", fontsize=10)
        plt.tight_layout()
        st.pyplot(fig)
        plt.close(fig)

    with right:
        st.subheader("💬 Interactions vs Rating")
        st.caption("Sanity check: if rating were just interactions, this'd be a perfect line.")
        fig, ax = plt.subplots(figsize=(8, 5))
        sns.scatterplot(
            data=metrics, x="interactions", y="star_rating",
            hue="department", size="tasks_completed",
            sizes=(50, 400), alpha=0.75, ax=ax,
        )
        sns.regplot(
            data=metrics, x="interactions", y="star_rating",
            scatter=False, ax=ax, color="#374151",
            line_kws={"linestyle": "--", "linewidth": 1.5},
        )
        ax.set_ylim(0, 5)
        ax.legend(bbox_to_anchor=(1.02, 1), loc="upper left", fontsize=8)
        plt.tight_layout()
        st.pyplot(fig)
        plt.close(fig)

    # Daily activity heatmap
    st.subheader("🔥 Daily Tasks Completed by Department")
    activity = db.daily_task_activity(date_from=d_from, date_to=d_to)
    if not activity.empty:
        pivot = activity.pivot_table(
            index="department", columns="date",
            values="tasks_completed", aggfunc="sum",
        ).fillna(0)
        fig, ax = plt.subplots(figsize=(14, 3.5))
        sns.heatmap(pivot, cmap="YlOrRd", linewidths=0.3, ax=ax,
                    cbar_kws={"label": "Tasks Done"})
        ax.set_xlabel("Date")
        ax.set_ylabel("")
        ax.set_xticklabels(
            [d.strftime("%d %b") for d in pivot.columns],
            rotation=45, ha="right",
        )
        plt.tight_layout()
        st.pyplot(fig)
        plt.close(fig)
    else:
        st.info("No completed tasks in this window.")

    # Leaderboard table
    st.subheader("🏅 Leaderboard")
    show = metrics.sort_values("star_rating", ascending=False).copy()
    show["⭐"] = show["star_rating"].apply(render_stars)
    show = show[[
        "employee", "department", "⭐", "star_rating",
        "tasks_completed", "total_tasks", "interactions",
        "hours_logged", "avg_peer_rating",
    ]].rename(columns={
        "employee": "Employee", "department": "Department",
        "star_rating": "Rating", "tasks_completed": "Done",
        "total_tasks": "Total Tasks", "interactions": "Interactions",
        "hours_logged": "Hours", "avg_peer_rating": "Peer ⌀",
    })
    st.dataframe(
        show, use_container_width=True, hide_index=True,
        column_config={
            "Rating": st.column_config.ProgressColumn(
                "Rating", min_value=0, max_value=5, format="%.2f",
            ),
        },
    )

    csv = show.to_csv(index=False).encode("utf-8")
    st.download_button("⬇️ Download leaderboard CSV", csv,
                       "leaderboard.csv", "text/csv")


# ===============================================================
# TAB 2 — EMPLOYEES CRUD
# ===============================================================
with tab_emp:
    st.title("👥 Employees")

    # ---- ADD form ----
    with st.expander("➕ Add new employee", expanded=False):
        with st.form("add_employee_form", clear_on_submit=True):
            c1, c2 = st.columns(2)
            with c1:
                new_name = st.text_input("Name *")
                new_dept = st.selectbox("Department *", db.DEPARTMENTS)
            with c2:
                new_email = st.text_input("Email")
                new_hire = st.date_input("Hire date", value=date.today())

            if st.form_submit_button("Add employee", type="primary"):
                try:
                    db.add_employee(new_name, new_dept, new_email or None, new_hire)
                    st.success(f"✅ Added {new_name}")
                    st.rerun()
                except sqlite3.IntegrityError if False else Exception as e:
                    st.error(f"Could not add: {e}")

    st.markdown("---")

    # ---- LIST + actions ----
    show_inactive = st.toggle("Show inactive employees", value=False)
    emps = db.list_employees(include_inactive=show_inactive)

    if emps.empty:
        st.info("No employees yet. Add one above.")
    else:
        # Column headers
        h = st.columns([2.5, 1.5, 2.5, 1.3, 0.8, 2.2])
        for col, name in zip(h, ["Name", "Department", "Email", "Hired", "Active", "Actions"]):
            col.markdown(f"**{name}**")
        st.markdown("---")

        for _, emp in emps.iterrows():
            emp_id = int(emp["id"])
            cols = st.columns([2.5, 1.5, 2.5, 1.3, 0.8, 2.2])
            cols[0].write(emp["name"])
            cols[1].write(emp["department"])
            cols[2].write(emp["email"] or "—")
            cols[3].write(
                emp["hire_date"].strftime("%Y-%m-%d")
                if pd.notna(emp["hire_date"]) else "—"
            )
            cols[4].write("✅" if emp["active"] else "💤")

            with cols[5]:
                bcols = st.columns(3)
                if bcols[0].button("✏️", key=f"edit_emp_{emp_id}", help="Edit"):
                    st.session_state.edit_employee_id = emp_id
                    st.rerun()
                if emp["active"]:
                    if bcols[1].button("💤", key=f"deact_{emp_id}",
                                       help="Deactivate (soft delete)"):
                        db.deactivate_employee(emp_id)
                        st.rerun()
                else:
                    if bcols[1].button("♻️", key=f"react_{emp_id}",
                                       help="Reactivate"):
                        db.reactivate_employee(emp_id)
                        st.rerun()
                if bcols[2].button("🗑️", key=f"del_emp_{emp_id}",
                                   help="Hard delete (removes all tasks!)"):
                    st.session_state.delete_confirm_employee = emp_id
                    st.rerun()

        # Delete confirmation
        if st.session_state.delete_confirm_employee:
            emp_id = st.session_state.delete_confirm_employee
            emp = db.get_employee(emp_id)
            st.error(
                f"⚠️ Hard-delete **{emp['name']}**? "
                "This will also delete all their tasks and interactions. "
                "Prefer 💤 (deactivate) to preserve history."
            )
            cdel1, cdel2, _ = st.columns([1, 1, 5])
            if cdel1.button("Yes, delete everything", type="primary"):
                db.hard_delete_employee(emp_id)
                st.session_state.delete_confirm_employee = None
                st.success("Deleted.")
                st.rerun()
            if cdel2.button("Cancel"):
                st.session_state.delete_confirm_employee = None
                st.rerun()

        # Edit form
        if st.session_state.edit_employee_id:
            emp_id = st.session_state.edit_employee_id
            emp = db.get_employee(emp_id)
            if emp is None:
                st.session_state.edit_employee_id = None
                st.rerun()
            st.markdown("---")
            st.subheader(f"✏️ Edit: {emp['name']}")
            with st.form("edit_employee_form"):
                c1, c2 = st.columns(2)
                with c1:
                    e_name = st.text_input("Name", value=emp["name"])
                    e_dept = st.selectbox(
                        "Department", db.DEPARTMENTS,
                        index=db.DEPARTMENTS.index(emp["department"]),
                    )
                with c2:
                    e_email = st.text_input("Email", value=emp["email"] or "")
                    e_hire = st.date_input(
                        "Hire date",
                        value=(
                            datetime.fromisoformat(emp["hire_date"]).date()
                            if emp["hire_date"] else date.today()
                        ),
                    )
                e_active = st.checkbox("Active", value=bool(emp["active"]))

                save, cancel = st.columns([1, 5])
                if save.form_submit_button("Save", type="primary"):
                    try:
                        db.update_employee(
                            emp_id, e_name, e_dept,
                            e_email or None, e_hire, e_active,
                        )
                        st.session_state.edit_employee_id = None
                        st.success("Saved.")
                        st.rerun()
                    except Exception as e:
                        st.error(str(e))
                if cancel.form_submit_button("Cancel"):
                    st.session_state.edit_employee_id = None
                    st.rerun()


# ===============================================================
# TAB 3 — TASKS CRUD
# ===============================================================
with tab_task:
    st.title("✅ Tasks")

    active_emps = db.list_employees(include_inactive=False)
    if active_emps.empty:
        st.warning("No active employees. Add some in the **Employees** tab first.")
        st.stop()

    emp_name_to_id = dict(zip(active_emps["name"], active_emps["id"]))

    # ---- ADD ----
    with st.expander("➕ Add new task", expanded=False):
        with st.form("add_task_form", clear_on_submit=True):
            c1, c2, c3 = st.columns(3)
            with c1:
                t_emp = st.selectbox("Assignee *", list(emp_name_to_id.keys()))
                t_title = st.text_input("Title *")
            with c2:
                t_status = st.selectbox("Status", db.TASK_STATUSES, index=0)
                t_priority = st.selectbox("Priority", db.PRIORITIES, index=1)
            with c3:
                t_due = st.date_input("Due date",
                                      value=date.today() + timedelta(days=7))
                t_hours = st.number_input("Hours logged", min_value=0.0,
                                          max_value=200.0, value=0.0, step=0.5)
            t_rating = st.slider("Peer rating (only meaningful when done)",
                                 1.0, 5.0, 3.0, 0.5)
            t_desc = st.text_area("Description", height=70)

            if st.form_submit_button("Add task", type="primary"):
                try:
                    db.add_task(
                        employee_id=int(emp_name_to_id[t_emp]),
                        title=t_title, status=t_status, priority=t_priority,
                        description=t_desc or None, due_date=t_due,
                        hours_logged=t_hours,
                        peer_rating=t_rating if t_status == "done" else None,
                    )
                    st.success(f"✅ Added task: {t_title}")
                    st.rerun()
                except Exception as e:
                    st.error(str(e))

    st.markdown("---")

    # ---- FILTERS + LIST ----
    f1, f2, f3 = st.columns([2, 2, 2])
    with f1:
        f_emp = st.selectbox(
            "Filter by employee", ["All"] + list(emp_name_to_id.keys()),
        )
    with f2:
        f_status = st.selectbox("Status", ["All"] + db.TASK_STATUSES)
    with f3:
        st.write("")
        st.write("")
        f_recent = st.checkbox("Last 30 days only", value=False)

    kwargs = {}
    if f_emp != "All":
        kwargs["employee_id"] = int(emp_name_to_id[f_emp])
    if f_status != "All":
        kwargs["status"] = f_status
    if f_recent:
        kwargs["date_from"] = date.today() - timedelta(days=30)

    tasks_df = db.list_tasks(**kwargs)
    st.caption(f"Showing **{len(tasks_df)}** task(s).")

    if tasks_df.empty:
        st.info("No tasks match these filters.")
    else:
        # Use data display + per-row edit/delete buttons via expander
        for _, task in tasks_df.head(50).iterrows():
            task_id = int(task["id"])
            status_emoji = {
                "todo": "📝", "in_progress": "🔄",
                "done": "✅", "cancelled": "❌",
            }[task["status"]]
            priority_color = {
                "low": "🟢", "medium": "🟡", "high": "🟠", "urgent": "🔴",
            }[task["priority"]]
            header = (
                f"{status_emoji} **{task['title']}** · "
                f"{task['employee_name']} ({task['department']}) · "
                f"{priority_color} {task['priority']}"
            )
            with st.expander(header):
                info_cols = st.columns(4)
                info_cols[0].metric("Status", task["status"])
                info_cols[1].metric("Hours", f"{task['hours_logged']:.1f}")
                info_cols[2].metric(
                    "Peer Rating",
                    f"{task['peer_rating']:.1f}" if pd.notna(task["peer_rating"]) else "—",
                )
                info_cols[3].metric(
                    "Due",
                    task["due_date"].strftime("%Y-%m-%d")
                    if pd.notna(task["due_date"]) else "—",
                )
                if task["description"]:
                    st.write(task["description"])

                ec1, ec2, _ = st.columns([1, 1, 5])
                if ec1.button("✏️ Edit", key=f"e_task_{task_id}"):
                    st.session_state.edit_task_id = task_id
                    st.rerun()
                if ec2.button("🗑️ Delete", key=f"d_task_{task_id}"):
                    st.session_state.delete_confirm_task = task_id
                    st.rerun()

        if len(tasks_df) > 50:
            st.caption(f"…and {len(tasks_df) - 50} more (refine filters to see).")

    # Delete confirm
    if st.session_state.delete_confirm_task:
        tid = st.session_state.delete_confirm_task
        st.error(f"⚠️ Delete task #{tid}? This cannot be undone.")
        c1, c2, _ = st.columns([1, 1, 5])
        if c1.button("Yes, delete", type="primary", key="confirm_del_task"):
            db.delete_task(tid)
            st.session_state.delete_confirm_task = None
            st.rerun()
        if c2.button("Cancel", key="cancel_del_task"):
            st.session_state.delete_confirm_task = None
            st.rerun()

    # Edit form
    if st.session_state.edit_task_id:
        tid = st.session_state.edit_task_id
        task_row = db.list_tasks()
        task_row = task_row[task_row["id"] == tid]
        if task_row.empty:
            st.session_state.edit_task_id = None
            st.rerun()
        task = task_row.iloc[0]
        st.markdown("---")
        st.subheader(f"✏️ Edit task: {task['title']}")
        with st.form("edit_task_form"):
            c1, c2, c3 = st.columns(3)
            with c1:
                et_title = st.text_input("Title", value=task["title"])
                et_status = st.selectbox(
                    "Status", db.TASK_STATUSES,
                    index=db.TASK_STATUSES.index(task["status"]),
                )
            with c2:
                et_priority = st.selectbox(
                    "Priority", db.PRIORITIES,
                    index=db.PRIORITIES.index(task["priority"]),
                )
                et_hours = st.number_input(
                    "Hours logged", min_value=0.0, max_value=200.0,
                    value=float(task["hours_logged"]), step=0.5,
                )
            with c3:
                et_due = st.date_input(
                    "Due date",
                    value=task["due_date"].date() if pd.notna(task["due_date"]) else date.today(),
                )
                et_rating = st.slider(
                    "Peer rating", 1.0, 5.0,
                    float(task["peer_rating"]) if pd.notna(task["peer_rating"]) else 3.0,
                    0.5,
                )
            et_desc = st.text_area("Description", value=task["description"] or "")

            sv, cn = st.columns([1, 5])
            if sv.form_submit_button("Save", type="primary"):
                try:
                    db.update_task(
                        tid, et_title, et_status, et_priority,
                        description=et_desc or None, due_date=et_due,
                        hours_logged=et_hours,
                        peer_rating=et_rating if et_status == "done" else None,
                    )
                    st.session_state.edit_task_id = None
                    st.success("Saved.")
                    st.rerun()
                except Exception as e:
                    st.error(str(e))
            if cn.form_submit_button("Cancel"):
                st.session_state.edit_task_id = None
                st.rerun()


# ===============================================================
# TAB 4 — INTERACTIONS CRUD
# ===============================================================
with tab_inter:
    st.title("💬 Interactions")
    st.caption(
        "Log meetings, code reviews, calls, mentoring sessions. "
        "Interactions feed into the 20% engagement portion of the star rating."
    )

    active_emps = db.list_employees(include_inactive=False)
    if active_emps.empty:
        st.warning("No active employees. Add some first.")
        st.stop()

    emp_name_to_id = dict(zip(active_emps["name"], active_emps["id"]))

    # ---- ADD ----
    with st.expander("➕ Log new interaction", expanded=False):
        with st.form("add_interaction_form", clear_on_submit=True):
            c1, c2, c3 = st.columns(3)
            with c1:
                i_emp = st.selectbox("Employee *", list(emp_name_to_id.keys()),
                                     key="add_i_emp")
            with c2:
                i_kind = st.selectbox("Kind *", db.INTERACTION_KINDS,
                                      key="add_i_kind")
            with c3:
                i_when = st.date_input("Date", value=date.today(),
                                       key="add_i_when")
            i_note = st.text_area("Note (optional)", height=70, key="add_i_note")

            if st.form_submit_button("Log interaction", type="primary"):
                try:
                    db.add_interaction(
                        employee_id=int(emp_name_to_id[i_emp]),
                        kind=i_kind, note=i_note or None,
                        occurred_at=datetime.combine(i_when, datetime.min.time()),
                    )
                    st.success("✅ Logged.")
                    st.rerun()
                except Exception as e:
                    st.error(str(e))

    st.markdown("---")

    # ---- LIST ----
    fc1, fc2 = st.columns(2)
    with fc1:
        fi_emp = st.selectbox(
            "Filter by employee", ["All"] + list(emp_name_to_id.keys()),
            key="filter_i_emp",
        )
    with fc2:
        fi_recent = st.checkbox("Last 30 days only", value=True,
                                key="filter_i_recent")

    kw = {}
    if fi_emp != "All":
        kw["employee_id"] = int(emp_name_to_id[fi_emp])
    if fi_recent:
        kw["date_from"] = date.today() - timedelta(days=30)

    inter_df = db.list_interactions(**kw)
    st.caption(f"Showing **{len(inter_df)}** interaction(s).")

    if inter_df.empty:
        st.info("No interactions match.")
    else:
        # Headers
        h = st.columns([1.8, 2, 1.5, 3, 1.5])
        for col, label in zip(h, ["When", "Employee", "Kind", "Note", "Actions"]):
            col.markdown(f"**{label}**")
        st.markdown("---")

        for _, row in inter_df.head(80).iterrows():
            iid = int(row["id"])
            cols = st.columns([1.8, 2, 1.5, 3, 1.5])
            cols[0].write(row["occurred_at"].strftime("%Y-%m-%d %H:%M"))
            cols[1].write(f"{row['employee_name']}")
            cols[2].write(row["kind"])
            cols[3].write(row["note"] or "—")
            with cols[4]:
                bc = st.columns(2)
                if bc[0].button("✏️", key=f"e_i_{iid}"):
                    st.session_state.edit_interaction_id = iid
                    st.rerun()
                if bc[1].button("🗑️", key=f"d_i_{iid}"):
                    st.session_state.delete_confirm_interaction = iid
                    st.rerun()

        if len(inter_df) > 80:
            st.caption(f"…and {len(inter_df) - 80} more.")

    # Delete confirm
    if st.session_state.delete_confirm_interaction:
        iid = st.session_state.delete_confirm_interaction
        st.error(f"⚠️ Delete interaction #{iid}?")
        c1, c2, _ = st.columns([1, 1, 5])
        if c1.button("Yes, delete", type="primary", key="confirm_del_i"):
            db.delete_interaction(iid)
            st.session_state.delete_confirm_interaction = None
            st.rerun()
        if c2.button("Cancel", key="cancel_del_i"):
            st.session_state.delete_confirm_interaction = None
            st.rerun()

    # Edit
    if st.session_state.edit_interaction_id:
        iid = st.session_state.edit_interaction_id
        all_i = db.list_interactions()
        row = all_i[all_i["id"] == iid]
        if row.empty:
            st.session_state.edit_interaction_id = None
            st.rerun()
        row = row.iloc[0]
        st.markdown("---")
        st.subheader(f"✏️ Edit interaction #{iid}")
        with st.form("edit_inter_form"):
            c1, c2 = st.columns(2)
            with c1:
                ei_kind = st.selectbox(
                    "Kind", db.INTERACTION_KINDS,
                    index=db.INTERACTION_KINDS.index(row["kind"]),
                )
            with c2:
                ei_when = st.date_input("Date", value=row["occurred_at"].date())
            ei_note = st.text_area("Note", value=row["note"] or "")

            sv, cn = st.columns([1, 5])
            if sv.form_submit_button("Save", type="primary"):
                try:
                    db.update_interaction(
                        iid, ei_kind, ei_note or None,
                        datetime.combine(ei_when, row["occurred_at"].time()),
                    )
                    st.session_state.edit_interaction_id = None
                    st.success("Saved.")
                    st.rerun()
                except Exception as e:
                    st.error(str(e))
            if cn.form_submit_button("Cancel"):
                st.session_state.edit_interaction_id = None
                st.rerun()
