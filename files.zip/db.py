"""
Database layer for the Employee Progress Dashboard.

Uses SQLite (file: employees.db). All mutations go through this module so
the Streamlit app stays focused on UI.

Tables:
    employees       - id, name, department, email, hire_date, active
    tasks           - id, employee_id, title, status, priority, hours, ...
    interactions    - id, employee_id, kind, occurred_at, note

Soft delete on employees (active=0) preserves historical task records.
Hard delete on tasks and interactions.
"""
from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from datetime import date, datetime, timedelta
from pathlib import Path
import random

import numpy as np
import pandas as pd

DB_PATH = Path(__file__).parent / "employees.db"

DEPARTMENTS = ["Engineering", "Sales", "Marketing", "Support", "Product"]
TASK_STATUSES = ["todo", "in_progress", "done", "cancelled"]
PRIORITIES = ["low", "medium", "high", "urgent"]
INTERACTION_KINDS = [
    "meeting", "1:1", "code_review", "client_call",
    "slack_thread", "presentation", "mentoring",
]


# ---------------------------------------------------------------
# Connection management
# ---------------------------------------------------------------
@contextmanager
def get_conn():
    """Yield a SQLite connection with foreign keys enabled."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


# ---------------------------------------------------------------
# Schema
# ---------------------------------------------------------------
SCHEMA = """
CREATE TABLE IF NOT EXISTS employees (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT    NOT NULL UNIQUE,
    department  TEXT    NOT NULL,
    email       TEXT,
    hire_date   DATE,
    active      INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS tasks (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id   INTEGER NOT NULL,
    title         TEXT    NOT NULL,
    description   TEXT,
    status        TEXT    NOT NULL CHECK(status IN ('todo','in_progress','done','cancelled')),
    priority      TEXT    NOT NULL CHECK(priority IN ('low','medium','high','urgent')),
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    due_date      DATE,
    completed_at  TIMESTAMP,
    hours_logged  REAL    NOT NULL DEFAULT 0,
    peer_rating   REAL,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS interactions (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id   INTEGER NOT NULL,
    kind          TEXT    NOT NULL,
    note          TEXT,
    occurred_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_tasks_employee ON tasks(employee_id);
CREATE INDEX IF NOT EXISTS idx_tasks_completed ON tasks(completed_at);
CREATE INDEX IF NOT EXISTS idx_interactions_employee ON interactions(employee_id);
CREATE INDEX IF NOT EXISTS idx_interactions_when ON interactions(occurred_at);
"""


def init_db() -> None:
    """Create tables if they don't exist, and seed if empty."""
    with get_conn() as conn:
        conn.executescript(SCHEMA)
        existing = conn.execute("SELECT COUNT(*) FROM employees").fetchone()[0]
    if existing == 0:
        seed_database()


# ---------------------------------------------------------------
# Employee CRUD
# ---------------------------------------------------------------
def list_employees(include_inactive: bool = False) -> pd.DataFrame:
    with get_conn() as conn:
        if include_inactive:
            q = "SELECT * FROM employees ORDER BY active DESC, name"
        else:
            q = "SELECT * FROM employees WHERE active = 1 ORDER BY name"
        df = pd.read_sql_query(q, conn, parse_dates=["hire_date"])
    df["active"] = df["active"].astype(bool)
    return df


def get_employee(emp_id: int) -> dict | None:
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM employees WHERE id = ?", (emp_id,)).fetchone()
    return dict(row) if row else None


def add_employee(
    name: str,
    department: str,
    email: str | None = None,
    hire_date: date | None = None,
) -> int:
    if not name or not name.strip():
        raise ValueError("Employee name is required.")
    if department not in DEPARTMENTS:
        raise ValueError(f"Department must be one of {DEPARTMENTS}.")
    with get_conn() as conn:
        cur = conn.execute(
            """INSERT INTO employees (name, department, email, hire_date, active)
               VALUES (?, ?, ?, ?, 1)""",
            (name.strip(), department, email, hire_date),
        )
        return cur.lastrowid


def update_employee(
    emp_id: int,
    name: str,
    department: str,
    email: str | None = None,
    hire_date: date | None = None,
    active: bool = True,
) -> None:
    with get_conn() as conn:
        conn.execute(
            """UPDATE employees
               SET name=?, department=?, email=?, hire_date=?, active=?
               WHERE id=?""",
            (name.strip(), department, email, hire_date, int(active), emp_id),
        )


def deactivate_employee(emp_id: int) -> None:
    """Soft delete — keeps historical tasks intact."""
    with get_conn() as conn:
        conn.execute("UPDATE employees SET active = 0 WHERE id = ?", (emp_id,))


def reactivate_employee(emp_id: int) -> None:
    with get_conn() as conn:
        conn.execute("UPDATE employees SET active = 1 WHERE id = ?", (emp_id,))


def hard_delete_employee(emp_id: int) -> None:
    """Hard delete — cascades to tasks and interactions. Use with care."""
    with get_conn() as conn:
        conn.execute("DELETE FROM employees WHERE id = ?", (emp_id,))


# ---------------------------------------------------------------
# Task CRUD
# ---------------------------------------------------------------
def list_tasks(
    employee_id: int | None = None,
    status: str | None = None,
    date_from: date | None = None,
    date_to: date | None = None,
) -> pd.DataFrame:
    q = """SELECT t.*, e.name AS employee_name, e.department
           FROM tasks t JOIN employees e ON e.id = t.employee_id
           WHERE 1=1"""
    params: list = []
    if employee_id is not None:
        q += " AND t.employee_id = ?"
        params.append(employee_id)
    if status:
        q += " AND t.status = ?"
        params.append(status)
    if date_from:
        q += " AND date(t.created_at) >= ?"
        params.append(date_from)
    if date_to:
        q += " AND date(t.created_at) <= ?"
        params.append(date_to)
    q += " ORDER BY t.created_at DESC"
    with get_conn() as conn:
        df = pd.read_sql_query(
            q, conn, params=params,
            parse_dates=["created_at", "completed_at", "due_date"],
        )
    return df


def add_task(
    employee_id: int,
    title: str,
    status: str = "todo",
    priority: str = "medium",
    description: str | None = None,
    due_date: date | None = None,
    hours_logged: float = 0.0,
    peer_rating: float | None = None,
) -> int:
    if not title or not title.strip():
        raise ValueError("Task title is required.")
    if status not in TASK_STATUSES:
        raise ValueError(f"Status must be one of {TASK_STATUSES}.")
    if priority not in PRIORITIES:
        raise ValueError(f"Priority must be one of {PRIORITIES}.")
    if peer_rating is not None and not (1 <= peer_rating <= 5):
        raise ValueError("Peer rating must be between 1 and 5.")

    completed_at = datetime.now() if status == "done" else None
    with get_conn() as conn:
        cur = conn.execute(
            """INSERT INTO tasks
                (employee_id, title, description, status, priority,
                 due_date, completed_at, hours_logged, peer_rating)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (employee_id, title.strip(), description, status, priority,
             due_date, completed_at, hours_logged, peer_rating),
        )
        return cur.lastrowid


def update_task(
    task_id: int,
    title: str,
    status: str,
    priority: str,
    description: str | None = None,
    due_date: date | None = None,
    hours_logged: float = 0.0,
    peer_rating: float | None = None,
) -> None:
    # Auto-stamp completion when moving to 'done'
    with get_conn() as conn:
        current = conn.execute(
            "SELECT status, completed_at FROM tasks WHERE id = ?", (task_id,)
        ).fetchone()
        if current is None:
            raise ValueError(f"Task {task_id} not found.")

        if status == "done" and current["status"] != "done":
            completed_at = datetime.now()
        elif status != "done":
            completed_at = None
        else:
            completed_at = current["completed_at"]

        conn.execute(
            """UPDATE tasks SET title=?, description=?, status=?, priority=?,
                 due_date=?, completed_at=?, hours_logged=?, peer_rating=?
               WHERE id=?""",
            (title.strip(), description, status, priority, due_date,
             completed_at, hours_logged, peer_rating, task_id),
        )


def delete_task(task_id: int) -> None:
    with get_conn() as conn:
        conn.execute("DELETE FROM tasks WHERE id = ?", (task_id,))


# ---------------------------------------------------------------
# Interaction CRUD
# ---------------------------------------------------------------
def list_interactions(
    employee_id: int | None = None,
    date_from: date | None = None,
    date_to: date | None = None,
) -> pd.DataFrame:
    q = """SELECT i.*, e.name AS employee_name, e.department
           FROM interactions i JOIN employees e ON e.id = i.employee_id
           WHERE 1=1"""
    params: list = []
    if employee_id is not None:
        q += " AND i.employee_id = ?"
        params.append(employee_id)
    if date_from:
        q += " AND date(i.occurred_at) >= ?"
        params.append(date_from)
    if date_to:
        q += " AND date(i.occurred_at) <= ?"
        params.append(date_to)
    q += " ORDER BY i.occurred_at DESC"
    with get_conn() as conn:
        df = pd.read_sql_query(q, conn, params=params, parse_dates=["occurred_at"])
    return df


def add_interaction(
    employee_id: int,
    kind: str,
    note: str | None = None,
    occurred_at: datetime | None = None,
) -> int:
    if kind not in INTERACTION_KINDS:
        raise ValueError(f"Kind must be one of {INTERACTION_KINDS}.")
    with get_conn() as conn:
        cur = conn.execute(
            """INSERT INTO interactions (employee_id, kind, note, occurred_at)
               VALUES (?, ?, ?, COALESCE(?, CURRENT_TIMESTAMP))""",
            (employee_id, kind, note, occurred_at),
        )
        return cur.lastrowid


def update_interaction(
    interaction_id: int,
    kind: str,
    note: str | None,
    occurred_at: datetime,
) -> None:
    with get_conn() as conn:
        conn.execute(
            """UPDATE interactions SET kind=?, note=?, occurred_at=?
               WHERE id=?""",
            (kind, note, occurred_at, interaction_id),
        )


def delete_interaction(interaction_id: int) -> None:
    with get_conn() as conn:
        conn.execute("DELETE FROM interactions WHERE id = ?", (interaction_id,))


# ---------------------------------------------------------------
# Aggregations for the dashboard tab
# ---------------------------------------------------------------
def employee_metrics(
    date_from: date | None = None,
    date_to: date | None = None,
) -> pd.DataFrame:
    """
    Per-employee aggregates over a date window.
    Returns columns suitable for KPI cards and charts.
    """
    df_emp = list_employees(include_inactive=False)
    if df_emp.empty:
        return pd.DataFrame()

    df_tasks = list_tasks(date_from=date_from, date_to=date_to)
    df_inter = list_interactions(date_from=date_from, date_to=date_to)

    # Tasks aggregates
    if df_tasks.empty:
        task_agg = pd.DataFrame(columns=[
            "employee_id", "total_tasks", "tasks_completed",
            "hours_logged", "avg_peer_rating",
        ])
    else:
        df_done = df_tasks[df_tasks["status"] == "done"]
        task_agg = (
            df_tasks.groupby("employee_id")
            .agg(
                total_tasks=("id", "count"),
                hours_logged=("hours_logged", "sum"),
            )
            .reset_index()
        )
        done_agg = (
            df_done.groupby("employee_id")
            .agg(
                tasks_completed=("id", "count"),
                avg_peer_rating=("peer_rating", "mean"),
            )
            .reset_index()
        )
        task_agg = task_agg.merge(done_agg, on="employee_id", how="left")

    # Interaction count
    if df_inter.empty:
        inter_agg = pd.DataFrame(columns=["employee_id", "interactions"])
    else:
        inter_agg = (
            df_inter.groupby("employee_id")
            .agg(interactions=("id", "count"))
            .reset_index()
        )

    out = df_emp.rename(columns={"id": "employee_id", "name": "employee"})
    out = out.merge(task_agg, on="employee_id", how="left")
    out = out.merge(inter_agg, on="employee_id", how="left")

    fill_zero = ["total_tasks", "tasks_completed", "hours_logged", "interactions"]
    for col in fill_zero:
        if col in out.columns:
            out[col] = out[col].fillna(0)
        else:
            out[col] = 0
    if "avg_peer_rating" not in out.columns:
        out["avg_peer_rating"] = np.nan
    out["avg_peer_rating"] = out["avg_peer_rating"].fillna(3.0)

    out["star_rating"] = compute_star_rating(out)
    return out


def compute_star_rating(df: pd.DataFrame) -> pd.Series:
    """
    Composite 1-5 star rating derived from real activity.

    Weights:
        35% tasks completed (output)
        30% avg peer rating (quality)
        20% interactions (engagement)
        15% hours logged (effort)

    Edit the weights here to re-tune the system.
    """
    tasks_norm = (df["tasks_completed"] / 20.0).clip(0, 1)
    interactions_norm = (df["interactions"] / 40.0).clip(0, 1)
    hours_norm = (df["hours_logged"] / 160.0).clip(0, 1)
    feedback_norm = ((df["avg_peer_rating"] - 1) / 4.0).clip(0, 1)

    composite = (
        0.35 * tasks_norm
        + 0.30 * feedback_norm
        + 0.20 * interactions_norm
        + 0.15 * hours_norm
    )
    return (1 + composite * 4).round(2)


def daily_task_activity(
    date_from: date,
    date_to: date,
) -> pd.DataFrame:
    """Tasks completed per day per department — for trend chart."""
    df_tasks = list_tasks(date_from=date_from, date_to=date_to)
    if df_tasks.empty:
        return pd.DataFrame(columns=["date", "department", "tasks_completed"])
    done = df_tasks[df_tasks["status"] == "done"].copy()
    if done.empty:
        return pd.DataFrame(columns=["date", "department", "tasks_completed"])
    done["date"] = pd.to_datetime(done["completed_at"]).dt.date
    return (
        done.groupby(["date", "department"])
        .agg(tasks_completed=("id", "count"))
        .reset_index()
    )


# ---------------------------------------------------------------
# Seed data — runs once on first launch
# ---------------------------------------------------------------
def seed_database() -> None:
    """Populate the DB with realistic sample data so the dashboard is useful immediately."""
    rng = random.Random(42)
    np_rng = np.random.default_rng(42)

    employees = [
        ("Aoife Murphy", "Engineering"), ("Conor O'Brien", "Engineering"),
        ("Niamh Walsh", "Engineering"), ("Sean Byrne", "Engineering"),
        ("Saoirse Kelly", "Engineering"), ("Cian Doyle", "Engineering"),
        ("Roisin Ryan", "Sales"), ("Padraig Lynch", "Sales"),
        ("Aine Connolly", "Sales"), ("Eoin Fitzgerald", "Sales"),
        ("Sinead Quinn", "Sales"), ("Liam Gallagher", "Marketing"),
        ("Maeve Brennan", "Marketing"), ("Oisin Reilly", "Marketing"),
        ("Caitlin Sullivan", "Marketing"), ("Darragh McCarthy", "Support"),
        ("Orla Healy", "Support"), ("Tadhg Power", "Support"),
        ("Sorcha Daly", "Support"), ("Fionn Burke", "Support"),
        ("Aisling Hayes", "Product"), ("Ruairi Moore", "Product"),
        ("Clodagh Nolan", "Product"), ("Diarmuid Hogan", "Product"),
        ("Iseult Foley", "Product"),
    ]

    task_titles_by_dept = {
        "Engineering": [
            "Fix login bug", "Code review for PR-{n}", "Refactor auth module",
            "Investigate prod incident", "Write unit tests for billing",
            "Deploy to staging", "Database migration", "API endpoint for reports",
            "Update dependencies", "Performance profiling",
        ],
        "Sales": [
            "Follow up with lead #{n}", "Demo for {n} prospects",
            "Quarterly pipeline review", "Renew contract with client {n}",
            "Cold outreach campaign", "Update CRM records",
            "Prepare proposal deck", "Account expansion call",
        ],
        "Marketing": [
            "Launch campaign #{n}", "Blog post on industry trends",
            "Social media calendar", "Email sequence for new product",
            "Analytics review", "SEO audit", "Webinar planning",
            "Brand asset refresh",
        ],
        "Support": [
            "Resolve ticket #{n}", "Customer onboarding call",
            "Update help docs", "Triage urgent issues",
            "Weekly support metrics report", "Train new team member",
            "Escalation handling", "FAQ revamp",
        ],
        "Product": [
            "User research interviews", "Spec for feature #{n}",
            "Roadmap update", "Sprint planning",
            "Competitive analysis", "Wireframe v{n}",
            "Stakeholder demo", "Backlog grooming",
        ],
    }

    with get_conn() as conn:
        # Insert employees
        emp_ids = {}
        for i, (name, dept) in enumerate(employees):
            hire_date = date.today() - timedelta(days=rng.randint(60, 2000))
            email = name.lower().replace(" ", ".").replace("'", "") + "@example.com"
            cur = conn.execute(
                """INSERT INTO employees (name, department, email, hire_date, active)
                   VALUES (?, ?, ?, ?, 1)""",
                (name, dept, email, hire_date),
            )
            emp_ids[name] = cur.lastrowid

        # Insert tasks — last 90 days
        today = datetime.now()
        for name, dept in employees:
            performance = np_rng.uniform(0.55, 0.95)
            n_tasks = int(np_rng.normal(performance * 25, 4))
            n_tasks = max(3, min(40, n_tasks))
            titles = task_titles_by_dept[dept]

            for _ in range(n_tasks):
                days_ago = rng.randint(0, 90)
                created = today - timedelta(days=days_ago)
                title = rng.choice(titles).format(n=rng.randint(100, 999))

                if rng.random() < performance:
                    status = "done"
                    completed = created + timedelta(
                        days=rng.randint(0, min(days_ago, 14)),
                        hours=rng.randint(0, 23),
                    )
                    peer_rating = round(float(np_rng.normal(performance * 5, 0.5)), 1)
                    peer_rating = max(1.0, min(5.0, peer_rating))
                else:
                    r = rng.random()
                    status = "in_progress" if r < 0.6 else ("todo" if r < 0.9 else "cancelled")
                    completed = None
                    peer_rating = None

                priority = rng.choices(
                    PRIORITIES, weights=[0.2, 0.5, 0.25, 0.05]
                )[0]
                hours = round(float(np_rng.uniform(0.5, 12)), 1)
                due = created + timedelta(days=rng.randint(1, 21))

                conn.execute(
                    """INSERT INTO tasks
                        (employee_id, title, description, status, priority,
                         created_at, due_date, completed_at, hours_logged, peer_rating)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (emp_ids[name], title, None, status, priority,
                     created, due.date(), completed, hours, peer_rating),
                )

            # Interactions
            n_inter = int(np_rng.normal(performance * 30, 5))
            n_inter = max(0, min(60, n_inter))
            for _ in range(n_inter):
                days_ago = rng.randint(0, 90)
                occurred = today - timedelta(
                    days=days_ago, hours=rng.randint(0, 23), minutes=rng.randint(0, 59),
                )
                kind = rng.choice(INTERACTION_KINDS)
                conn.execute(
                    """INSERT INTO interactions (employee_id, kind, note, occurred_at)
                       VALUES (?, ?, ?, ?)""",
                    (emp_ids[name], kind, None, occurred),
                )
